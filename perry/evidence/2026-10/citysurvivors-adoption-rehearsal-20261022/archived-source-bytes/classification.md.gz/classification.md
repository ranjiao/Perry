# CS-078 程序文档分类与处置清单

| 字段 | 内容 |
| --- | --- |
| 文档ID | tech.evidence.cs078-classification |
| 类型／负责人 | 分类与处置索引／程序 |
| 用途／读者 | 对象总表与索引／程序、策划；CS-080复核者 |
| 维护方式 | 持续维护 |
| 生命周期／修订／更新 | 当前／1.0／2026-10-22 |
| 适用范围 | 程序当前源、原位历史、归档及指南；非组件／素材参数台账 |
| 依据／关联 | CS-078；[检查报告](2026-10-22-documentation-review.md)、[用途规范](../../production/documentation-standard.md) |

完整原路径／当前位置、段落后继、前后完整SHA256与实时／快照消费者见[migrations.json](../../qa/documentation-cs078/migrations.json)。下表按用途登记，不再建立一套专业参数或资产总账。旧元信息缺用途的历史原件由本表分类，保持原字节。

当前入口是[程序首页](../README.md)；QA及归档由各自索引直接可达。旧tools根说明保留权限边界和原字节，当前操作进入两份新指南。没有独立未定工作稿；task结束结论与重复段去向见报告。

## 持续维护的正式源

| 文件 | 主要用途 | 主要读者 | 维护方式／处置 |
| --- | --- | --- | --- |
| [docs/archive/qa/README.md](../../archive/qa/README.md) | 对象总表与索引 | 程序；历史复核者 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/archive/tech/README.md](../../archive/tech/README.md) | 对象总表与索引 | 程序；历史复核者 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/qa/README.md](../../qa/README.md) | 对象总表与索引 | 程序、策划；验证与历史复核者 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/qa/asset-handoff-v1-checklist.md](../../qa/asset-handoff-v1-checklist.md) | 协作接口与交付要求 | 程序、美术；首件验收执行者 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/README.md](../README.md) | 对象总表与索引 | 程序、策划、美术；按目的导航 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/architecture.md](../architecture.md) | 长期专业资料 | 程序维护者；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/asset-integration.md](../asset-integration.md) | 协作接口与交付要求 | 程序、美术；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/cbd-path-recovery.md](../cbd-path-recovery.md) | 长期专业资料 | 程序维护者；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/cbd-pressure.md](../cbd-pressure.md) | 长期专业资料 | 程序维护者；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/character-action-state.md](../character-action-state.md) | 长期专业资料 | 程序维护者；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/character-animation-handoff-v1.md](../character-animation-handoff-v1.md) | 协作接口与交付要求 | 程序、美术；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/city-streaming-v1.md](../city-streaming-v1.md) | 长期专业资料 | 程序维护者；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/combat-hud.md](../combat-hud.md) | 长期专业资料 | 程序维护者；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/combat-lab.md](../combat-lab.md) | 长期专业资料 | 程序维护者；策划按需 | 持续维护；原位组件；操作段提炼到guides/combat-lab.md |
| [docs/tech/component-details.md](../component-details.md) | 长期专业资料 | 程序维护者；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/components.md](../components.md) | 对象总表与索引 | 程序、策划、美术；按目的导航 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/current-build.md](../current-build.md) | 项目治理与协调 | 程序、策划；采用与任务核对者 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/destruction.md](../destruction.md) | 长期专业资料 | 程序维护者；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/effects-audio-handoff-v1.md](../effects-audio-handoff-v1.md) | 协作接口与交付要求 | 程序、美术；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/evidence/README.md](README.md) | 对象总表与索引 | 程序、策划；CS-080复核者 | 持续维护；新增正式源／索引，内容来自本轮提炼或检查 |
| [docs/tech/evidence/classification.md](classification.md) | 对象总表与索引 | 程序、策划；CS-080复核者 | 持续维护；新增正式源／索引，内容来自本轮提炼或检查 |
| [docs/tech/guides/combat-lab.md](../guides/combat-lab.md) | 使用指南 | 程序、策划、美术；工具实际使用者 | 持续维护；新增正式源／索引，内容来自本轮提炼或检查 |
| [docs/tech/guides/ui-editor.md](../guides/ui-editor.md) | 使用指南 | 程序、策划、美术；工具实际使用者 | 持续维护；新增正式源／索引，内容来自本轮提炼或检查 |
| [docs/tech/hud-layout-editor.md](../hud-layout-editor.md) | 长期专业资料 | 程序维护者；策划按需 | 持续维护；原位组件；操作段到guides/ui-editor.md，字段到ui-layout-contract.md |
| [docs/tech/interactive-prop-handoff-v1.md](../interactive-prop-handoff-v1.md) | 协作接口与交付要求 | 程序、美术；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/interactive-props-v1.md](../interactive-props-v1.md) | 长期专业资料 | 程序维护者；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/m1-cbd-integration.md](../m1-cbd-integration.md) | 长期专业资料 | 程序维护者；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/map-streaming-contract-v1.md](../map-streaming-contract-v1.md) | 协作接口与交付要求 | 程序、美术；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/networking.md](../networking.md) | 协作接口与交付要求 | 程序、美术；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/performance-budget.md](../performance-budget.md) | 长期专业资料 | 程序维护者；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/qianya-hitboxes-v10.md](../qianya-hitboxes-v10.md) | 长期专业资料 | 程序维护者；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/todo.md](../todo.md) | 项目治理与协调 | 程序、策划；采用与任务核对者 | 持续维护；原位维护，补用途／读者／维护方式 |
| [docs/tech/ui-layout-contract.md](../ui-layout-contract.md) | 协作接口与交付要求 | 程序、美术；策划按需 | 持续维护；新增正式源／索引，内容来自本轮提炼或检查 |
| [docs/tech/weapon-handoff-v1.md](../weapon-handoff-v1.md) | 协作接口与交付要求 | 程序、美术；策划按需 | 持续维护；原位维护，补用途／读者／维护方式 |
| [game/README.md](../../../game/README.md) | 使用指南 | 程序、策划、美术；工具实际使用者 | 持续维护；原位维护，补用途／读者／维护方式 |
| [tests/README.md](../../../tests/README.md) | 使用指南 | 程序、策划、美术；工具实际使用者 | 持续维护；原位维护，补用途／读者／维护方式 |
| [tools/README.md](../../../tools/README.md) | 使用指南 | 程序、策划、美术；工具实际使用者 | 持续维护；原位权限例外；保持原字节，新操作经程序指南进入 |

## 历史留证与固定路径原件

| 文件 | 主要用途 | 主要读者 | 维护方式／处置 |
| --- | --- | --- | --- |
| [docs/archive/qa/2026/asset-handoff-v1-doc-check.md](../../archive/qa/2026/asset-handoff-v1-doc-check.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/qa/2026/coop-validation-v04.md](../../archive/qa/2026/coop-validation-v04.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/qa/2026/framework-validation-v01.md](../../archive/qa/2026/framework-validation-v01.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/qa/2026/input-fix-v01.md](../../archive/qa/2026/input-fix-v01.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/qa/2026/p0-validation-v02.md](../../archive/qa/2026/p0-validation-v02.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/qa/2026/presentation-validation-v05.md](../../archive/qa/2026/presentation-validation-v05.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/qa/2026/short-loop-validation-v01.md](../../archive/qa/2026/short-loop-validation-v01.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/qa/2026/test-ground-validation-v03.md](../../archive/qa/2026/test-ground-validation-v03.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/tech/2026/architecture.md](../../archive/tech/2026/architecture.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/tech/2026/coop-mechanics-v04.md](../../archive/tech/2026/coop-mechanics-v04.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/tech/2026/desktop-presentation-v05.md](../../archive/tech/2026/desktop-presentation-v05.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/tech/2026/engine-platform.md](../../archive/tech/2026/engine-platform.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/tech/2026/framework.md](../../archive/tech/2026/framework.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/tech/2026/networking.md](../../archive/tech/2026/networking.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/tech/2026/p0-playtest-v02.md](../../archive/tech/2026/p0-playtest-v02.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/tech/2026/short-loop.md](../../archive/tech/2026/short-loop.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/tech/2026/test-ground-v03.md](../../archive/tech/2026/test-ground-v03.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/archive/tech/2026/todo-research-record.md](../../archive/tech/2026/todo-research-record.md) | 验证与历史证据 | 程序、策划；复核角色按需 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/2026-10-20-action-state-validation.md](../../qa/2026-10-20-action-state-validation.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/2026-10-20-layered-animation-validation.md](../../qa/2026-10-20-layered-animation-validation.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/2026-10-20-m1-cbd-validation.md](../../qa/2026-10-20-m1-cbd-validation.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/2026-10-20-pitch-validation.md](../../qa/2026-10-20-pitch-validation.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/2026-10-21-cbd-path-recovery-validation.md](../../qa/2026-10-21-cbd-path-recovery-validation.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/2026-10-21-cbd-pressure-validation.md](../../qa/2026-10-21-cbd-pressure-validation.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/2026-10-21-combat-lab-validation.md](../../qa/2026-10-21-combat-lab-validation.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/2026-10-21-ui-kit-readiness.md](../../qa/2026-10-21-ui-kit-readiness.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/2026-10-21-unified-lab-validation.md](../../qa/2026-10-21-unified-lab-validation.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/2026-10-22-hud-editor-validation.md](../../qa/2026-10-22-hud-editor-validation.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/2026-10-22-ui-studio-validation.md](../../qa/2026-10-22-ui-studio-validation.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/ballistics-validation-v06.md](../../qa/ballistics-validation-v06.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/city-stream-v1-checklist.md](../../qa/city-stream-v1-checklist.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/coop-checklist-v04.md](../../qa/coop-checklist-v04.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/desktop-checklist-v05.md](../../qa/desktop-checklist-v05.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/lujiazui-free-roam-checklist.md](../../qa/lujiazui-free-roam-checklist.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/lujiazui-v002-checklist.md](../../qa/lujiazui-v002-checklist.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/m1-waves-validation-v08.md](../../qa/m1-waves-validation-v08.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/p0-playtest-checklist-v02.md](../../qa/p0-playtest-checklist-v02.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/props-v1-checklist.md](../../qa/props-v1-checklist.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/refactor-v1-checklist.md](../../qa/refactor-v1-checklist.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/test-ground-checklist-v03.md](../../qa/test-ground-checklist-v03.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/qa/tracer-checklist-v06.md](../../qa/tracer-checklist-v06.md) | 验证与历史证据 | 程序、策划、美术；按被测版本复核 | 历史留证；原位历史留证，保留原字节 |
| [docs/tech/2026-10-20-documentation-review.md](../2026-10-20-documentation-review.md) | 验证与历史证据 | 程序、策划；原时点交付复核者 | 历史留证；原位历史留证，保留原字节 |
| [docs/tech/architecture-review-v1.md](../architecture-review-v1.md) | 验证与历史证据 | 程序、策划；原时点交付复核者 | 历史留证；原位历史留证，保留原字节 |
| [docs/tech/character-integration-v09.md](../character-integration-v09.md) | 验证与历史证据 | 程序、策划；原时点交付复核者 | 历史留证；原位历史留证，保留原字节 |
| [docs/tech/evidence/2026-10-22-documentation-review.md](2026-10-22-documentation-review.md) | 验证与历史证据 | 程序、策划；CS-080复核者 | 历史留证；新增正式源／索引，内容来自本轮提炼或检查 |
| [docs/tech/lujiazui-free-roam.md](../lujiazui-free-roam.md) | 验证与历史证据 | 程序、策划；原时点交付复核者 | 历史留证；原位历史留证，保留原字节 |
| [docs/tech/lujiazui-v002-integration.md](../lujiazui-v002-integration.md) | 验证与历史证据 | 程序、策划；原时点交付复核者 | 历史留证；原位历史留证，保留原字节 |
| [docs/tech/m1-waves-v08.md](../m1-waves-v08.md) | 验证与历史证据 | 程序、策划；原时点交付复核者 | 历史留证；原位历史留证，保留原字节 |
| [docs/tech/refactor-v1.md](../refactor-v1.md) | 验证与历史证据 | 程序、策划；原时点交付复核者 | 历史留证；原位历史留证，保留原字节 |
| [docs/tech/tps-handling-v07.md](../tps-handling-v07.md) | 验证与历史证据 | 程序、策划；原时点交付复核者 | 历史留证；原位历史留证，保留原字节 |
| [docs/tech/weapon-presentation-v06.md](../weapon-presentation-v06.md) | 验证与历史证据 | 程序、策划；原时点交付复核者 | 历史留证；原位历史留证，保留原字节 |
| [game/assets/README.md](../../../game/assets/README.md) | 验证与历史证据 | 程序；运行副本历史核对者 | 历史留证；原位历史留证，保留原字节 |
| [game/assets/environment/lujiazui_v002/README.md](../../../game/assets/environment/lujiazui_v002/README.md) | 验证与历史证据 | 程序；运行副本历史核对者 | 历史留证；原位历史留证，保留原字节 |

